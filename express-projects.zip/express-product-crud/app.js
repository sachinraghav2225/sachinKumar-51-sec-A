const express = require("express");
const methodOverride = require("method-override");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use(express.urlencoded({ extended: true }));
app.use(methodOverride("_method")); // lets HTML forms send PUT and DELETE via ?_method=
app.use(express.static(path.join(__dirname, "public")));

// In-memory product data (name, price, description)
let products = [
  { id: 1, name: "Notebook", price: 60, description: "200 page ruled notebook" },
  { id: 2, name: "Pen", price: 10, description: "Blue ball point pen" },
];
let nextId = 3;

function validate(body) {
  const name = (body.name || "").trim();
  const description = (body.description || "").trim();
  const price = Number(body.price);
  if (!name || !description || body.price === "" || Number.isNaN(price) || price < 0) {
    return { error: "Name, description and a valid price (0 or more) are required." };
  }
  return { data: { name, price, description } };
}

app.get("/", (req, res) => res.redirect("/products"));

// READ all  -> GET /products
app.get("/products", (req, res) => {
  res.render("index", { title: "Products", products });
});

// New form  -> GET /products/new  (must be before /products/:id)
app.get("/products/new", (req, res) => {
  res.render("new", { title: "Add product", product: {}, error: null });
});

// CREATE    -> POST /products
app.post("/products", (req, res) => {
  const result = validate(req.body);
  if (result.error) {
    return res.status(400).render("new", { title: "Add product", product: req.body, error: result.error });
  }
  products.push({ id: nextId++, ...result.data });
  res.redirect("/products");
});

// READ one  -> GET /products/:id
app.get("/products/:id", (req, res) => {
  const product = products.find((p) => p.id === Number(req.params.id));
  if (!product) return res.status(404).render("404", { title: "Not found" });
  res.render("show", { title: product.name, product });
});

// Edit form -> GET /products/:id/edit
app.get("/products/:id/edit", (req, res) => {
  const product = products.find((p) => p.id === Number(req.params.id));
  if (!product) return res.status(404).render("404", { title: "Not found" });
  res.render("edit", { title: "Edit product", product, error: null });
});

// UPDATE    -> PUT /products/:id
app.put("/products/:id", (req, res) => {
  const product = products.find((p) => p.id === Number(req.params.id));
  if (!product) return res.status(404).render("404", { title: "Not found" });
  const result = validate(req.body);
  if (result.error) {
    return res.status(400).render("edit", {
      title: "Edit product",
      product: { id: product.id, ...req.body },
      error: result.error,
    });
  }
  Object.assign(product, result.data);
  res.redirect("/products");
});

// DELETE    -> DELETE /products/:id
app.delete("/products/:id", (req, res) => {
  products = products.filter((p) => p.id !== Number(req.params.id));
  res.redirect("/products");
});

app.use((req, res) => res.status(404).render("404", { title: "Not found" }));

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
