How to run:
1. Install Node.js (https://nodejs.org)
2. Open a terminal in this folder
3. npm install
4. npm start
5. Open http://localhost:3000 in the browser
