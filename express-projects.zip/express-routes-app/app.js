const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Template engine setup (EJS)
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middleware
app.use(express.urlencoded({ extended: true })); // read form data (POST body)
app.use(express.static(path.join(__dirname, "public")));

// In-memory storage for contact messages
const messages = [];

// 1. GET /  -> home page
app.get("/", (req, res) => {
  res.render("index", { title: "Home" });
});

// 2. GET /about -> about page
app.get("/about", (req, res) => {
  res.render("about", { title: "About" });
});

// 3. GET /contact -> show contact form
app.get("/contact", (req, res) => {
  res.render("contact", { title: "Contact", error: null });
});

// 4. POST /contact -> receive form data
app.post("/contact", (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).render("contact", {
      title: "Contact",
      error: "All fields are required.",
    });
  }
  messages.push({ name, email, message, time: new Date().toLocaleString() });
  res.redirect("/messages");
});

// 5. GET /messages -> list all received messages
app.get("/messages", (req, res) => {
  res.render("messages", { title: "Messages", messages });
});

// 6. POST /messages/clear -> delete all messages
app.post("/messages/clear", (req, res) => {
  messages.length = 0;
  res.redirect("/messages");
});

// 7. GET /users/:name -> route with URL parameter
app.get("/users/:name", (req, res) => {
  res.render("user", { title: "User", name: req.params.name });
});

// 404 handler (must be last)
app.use((req, res) => {
  res.status(404).render("404", { title: "Not found" });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
